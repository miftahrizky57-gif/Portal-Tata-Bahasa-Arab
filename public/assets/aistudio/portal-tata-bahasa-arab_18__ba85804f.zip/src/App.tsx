import { useState, useMemo, useRef, type FormEvent } from 'react';
import { BookOpen, Construction, Info, X, Check, Globe, GraduationCap, ShieldAlert, Sparkles, Quote, ArrowLeft, ArrowRight, User, ChevronUp, ChevronDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import DashboardView from './components/DashboardView';
import { UserSession, ArabicQuote } from './types';
import { ARABIC_QUOTES } from './data/materiData';
import { isOfflineMode, setOfflineMode } from './lib/firebase';

interface FloatingLetter {
  id: number;
  char: string;
  fontSize: string;
  left: string;
  animationDuration: string;
  animationDelay: string;
}

export default function App() {
  const [nama, setNama] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [peran, setPeran] = useState<'siswa' | 'guru' | 'admin'>('siswa');
  const [gender, setGender] = useState<'laki-laki' | 'perempuan'>('laki-laki');
  const [kelas, setKelas] = useState<string>('7');
  const [activeView, setActiveView] = useState<'login' | 'proverb'>('login');
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState<number>(0);
  const [offline, setOfflineState] = useState<boolean>(() => isOfflineMode());
  
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusType, setStatusType] = useState<'success' | 'info' | 'error' | null>(null);
  const [session, setSession] = useState<UserSession | null>(null);

  // Global Arabic Accessibility Options
  const [arabicScale, setArabicScale] = useState<number>(1.25); // Range from 0.8 to 2.5
  const [arabicFontFamily, setArabicFontFamily] = useState<string>('Traditional Arabic');
  const [isArabicBold, setIsArabicBold] = useState<boolean>(true);
  const [isDragging, setIsDragging] = useState<boolean>(false);

  const dragStartY = useRef<number>(0);
  const dragStartScale = useRef<number>(1.25);

  // Generate floating Arabic letters for background
  const floatingLetters = useMemo<FloatingLetter[]>(() => {
    const lettersArray = [
      'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي'
    ];
    const list: FloatingLetter[] = [];
    for (let i = 0; i < 22; i++) {
      const char = lettersArray[Math.floor(Math.random() * lettersArray.length)];
      const size = 18 + Math.random() * 30;
      const left = Math.random() * 100;
      const durationNum = 14 + Math.random() * 18;
      const delayNum = -Math.random() * durationNum;
      list.push({
        id: i,
        char,
        fontSize: `${size.toFixed(1)}px`,
        left: `${left.toFixed(2)}%`,
        animationDuration: `${durationNum.toFixed(2)}s`,
        animationDelay: `${delayNum.toFixed(2)}s`,
      });
    }
    return list;
  }, []);

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const trimmedName = nama.trim();

    if (peran === 'admin') {
      const normalizeName = (str: string): string => {
        return str
          .toLowerCase()
          .replace(/[.,]/g, '')
          .replace(/\s+/g, ' ')
          .trim();
      };

      const normalizedInput = normalizeName(trimmedName);
      const normalizedTarget = normalizeName('Miftah Rizki Abdulloh, S.Ag.');

      // Flexible check allowing minor spacing/punctuation/casing differences
      const isMatch = normalizedInput === normalizedTarget || normalizedInput === 'miftah rizki abdulloh';

      if (!isMatch) {
        setIsLoading(false);
        setStatusType('error');
        setStatusMessage('Maaf, hanya Miftah Rizki Abdulloh, S.Ag. yang memiliki hak akses sebagai Administrator.');
        return;
      }

      // Check Admin Password ("21 04 02")
      const cleanAdminPass = password.replace(/\s+/g, '');
      if (cleanAdminPass !== '210402') {
        setIsLoading(false);
        setStatusType('error');
        setStatusMessage('Kata sandi Administrator salah. Silakan periksa kembali kata sandi khusus Admin Anda.');
        return;
      }
    }

    if (peran === 'guru') {
      if (!trimmedName) {
        setIsLoading(false);
        setStatusType('error');
        setStatusMessage('Nama Guru wajib diisi dan harus menyertakan gelar akademik/keagamaan.');
        return;
      }

      // Check Guru Password ("Tsanawiyyah Nurul islam")
      const cleanGuruPass = password.toLowerCase().trim();
      if (cleanGuruPass !== 'tsanawiyyah nurul islam' && cleanGuruPass.replace(/\s+/g, '') !== 'tsanawiyyahnurulislam') {
        setIsLoading(false);
        setStatusType('error');
        setStatusMessage('Kata sandi Guru salah. Silakan periksa kembali kata sandi khusus Guru (Tsanawiyyah Nurul islam).');
        return;
      }

      // Helper function to check for titles
      const hasGelar = (name: string): boolean => {
        const lowerName = name.toLowerCase();
        const commonTitles = [
          's.ag', 'spd', 's.pd', 'mpd', 'm.pd', 'lc', 'm.a', 'drs', 'dr', 'h.', 'hj', 'prof', 
          'ustadz', 'ustad', 'ustadzah', 'shi', 's.h.i', 'spdi', 's.p.d.i', 'mpdi', 'm.p.d.i',
          'ssos', 's.sos', 's.e', 'se', 'skom', 's.kom', 's.t', 'st'
        ];
        
        const words = lowerName.split(/[\s,]+/);
        const hasMatchingWord = words.some(word => {
          const cleanWord = word.replace(/[.,]/g, '');
          return commonTitles.includes(word) || commonTitles.includes(cleanWord);
        });

        const hasCommaAndTitleSuffix = /,\s*[a-zA-Z]{2,}/.test(lowerName);
        const hasDotsAbbreviation = /\b[a-zA-Z]{1,2}\.[a-zA-Z]{1,2}\.?/.test(lowerName);

        return hasMatchingWord || hasCommaAndTitleSuffix || hasDotsAbbreviation;
      };

      if (!hasGelar(trimmedName)) {
        setIsLoading(false);
        setStatusType('error');
        setStatusMessage('Untuk akses Guru, silakan tambahkan gelar akademis atau keagamaan pada nama Anda (misal: S.Ag., S.Pd., M.Pd., Lc., Ustadz, dll.)');
        return;
      }
    }

    setIsLoading(true);
    setStatusMessage(null);
    setStatusType(null);

    // Default name if empty (only for siswa)
    const resolvedName = trimmedName || (gender === 'laki-laki' ? 'Ahmad Mulya' : 'Siti Aisyah');

    // Simulate login verification with redirection to dashboard
    setTimeout(() => {
      setIsLoading(false);
      setStatusType('success');
      const roleCapitalized = peran.charAt(0).toUpperCase() + peran.slice(1);
      setStatusMessage(
        `Berhasil! Anda masuk sebagai ${roleCapitalized} (${gender === 'laki-laki' ? 'Laki-laki' : 'Perempuan'})${
          peran === 'siswa' ? ` Kelas ${kelas}` : ''
        }. Mengalihkan ke Dashboard...`
      );
      
      // Delay transition to dashboard for better feedback feel
      setTimeout(() => {
        setSession({
          peran,
          gender,
          kelas,
          name: resolvedName
        });
      }, 800);

    }, 1200);
  };

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950">
      <AnimatePresence mode="wait" initial={false}>
        {!session ? (
          <motion.div
            key="login-stage"
            initial={{ opacity: 0, scale: 0.98, filter: 'blur(8px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 1.02, filter: 'blur(12px)' }}
            transition={{ duration: 0.55, ease: [0.34, 1.56, 0.64, 1] }}
            className="w-full h-full"
          >
            <div className="stage relative w-full h-screen min-h-[600px] overflow-hidden bg-gradient-to-br from-[#0a2c5c] via-[#0d3b78] to-[#1f6fe5]">
              {/* Unified plain blue layout */}

      {/* LOGIN CARD CONTAINER */}
      <div className="card-wrap">
        <motion.div layout className="card">
          <AnimatePresence mode="wait">
            {activeView === 'login' ? (
              <motion.div
                key="login-view"
                initial={{ opacity: 0, x: -16, scale: 0.98 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 16, scale: 0.98 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
              >
                {/* Rounded gradient top emblem - replaced with an elegant BookOpen icon */}
                <div className="mark">
                  <BookOpen className="w-5 h-5 text-[#ffb020]" />
                </div>

                {/* Floating Arabic title banner */}
                <div className="title-wrap" style={{ textAlign: 'center' }}>
                  <h1 
                    className="title3d transition-all duration-75"
                    style={{
                      fontFamily: arabicFontFamily,
                      fontSize: `${20 * arabicScale}px`,
                      fontWeight: isArabicBold ? 'bold' : 'normal',
                      lineHeight: 1.5
                    }}
                  >
                    مُدْخَلُ القَوَاعِدِ الْعَرَبِيَّةِ لِلْمُبْتَدِئِينَ
                  </h1>
                </div>
                <p className="sub">Masuk untuk melanjutkan pembelajaran tata bahasa Arab</p>

                {/* Stateful Notification Banner */}
                {statusMessage && (
                  <div className={`mb-4 p-3 rounded-lg flex items-start gap-2.5 border text-xs leading-relaxed animate-fade-in ${
                    statusType === 'success' 
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                      : statusType === 'error'
                      ? 'bg-rose-50 border-rose-200 text-rose-800'
                      : 'bg-blue-50 border-blue-200 text-blue-800'
                  }`}>
                    {statusType === 'success' ? (
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    ) : statusType === 'error' ? (
                      <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                    ) : (
                      <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">{statusMessage}</div>
                    <button 
                      type="button" 
                      onClick={() => setStatusMessage(null)} 
                      className="text-gray-400 hover:text-gray-600 transition cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}

                {/* Form */}
                <form id="loginForm" onSubmit={handleSubmit}>
                  {/* Field: Nama Lengkap */}
                  <div className="field">
                    <label className="group-label" htmlFor="nama">
                      {peran === 'siswa' ? 'Nama Lengkap (Opsional)' : 'Nama Lengkap'}
                    </label>
                    <input 
                      type="text" 
                      id="nama" 
                      name="nama" 
                      value={nama}
                      onChange={(e) => setNama(e.target.value)}
                      placeholder={
                        peran === 'siswa' 
                          ? 'Masukkan Nama Anda (opsional)' 
                          : peran === 'admin'
                          ? 'Miftah Rizki Abdulloh, S.Ag.'
                          : 'Masukkan nama lengkap beserta gelar (contoh: Ahmad, S.Pd.)'
                      }
                      className="w-full p-2.5 bg-[#f7fafc] border border-[#e2e8f0] focus:border-[#1f6fe5] focus:bg-white focus:ring-2 focus:ring-[#1f6fe5]/10 rounded-lg text-xs font-semibold text-slate-800 outline-none transition"
                    />
                  </div>

                  {/* Field: Password (Hanya untuk Admin & Guru) */}
                  {(peran === 'admin' || peran === 'guru') && (
                    <div className="field">
                      <label className="group-label" htmlFor="password">
                        Kata Sandi Khusus {peran === 'admin' ? 'Administrator' : 'Guru'}
                      </label>
                      <input 
                        type="password" 
                        id="password" 
                        name="password" 
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder={
                          peran === 'admin' 
                            ? 'Masukkan Kata Sandi Admin' 
                            : 'Masukkan Kata Sandi Guru'
                        }
                        className="w-full p-2.5 bg-[#f7fafc] border border-[#e2e8f0] focus:border-[#1f6fe5] focus:bg-white focus:ring-2 focus:ring-[#1f6fe5]/10 rounded-lg text-xs font-semibold text-slate-800 outline-none transition"
                        required
                      />
                    </div>
                  )}

                  {/* Field: Peran (Role selection pills) */}
                  <div className="field">
                    <label className="group-label">Masuk sebagai</label>
                    <div className="pill-group" role="radiogroup" aria-label="Peran">
                      {/* Siswa */}
                      <input 
                        type="radio" 
                        name="peran" 
                        id="peran-siswa" 
                        value="siswa" 
                        checked={peran === 'siswa'}
                        onChange={() => setPeran('siswa')}
                      />
                      <label htmlFor="peran-siswa" className="pill">
                        <svg viewBox="0 0 24 24" fill="none" stroke="#1f6fe5" strokeWidth="2">
                          <path d="M12 3 1 8l11 5 9-4.09V17h2V8L12 3Z"/>
                          <path d="M5 10.5V16c0 1.5 3 3 7 3s7-1.5 7-3v-5.5" strokeLinecap="round"/>
                        </svg>
                        Siswa
                      </label>

                      {/* Guru */}
                      <input 
                        type="radio" 
                        name="peran" 
                        id="peran-guru" 
                        value="guru"
                        checked={peran === 'guru'}
                        onChange={() => setPeran('guru')}
                      />
                      <label htmlFor="peran-guru" className="pill">
                        <svg viewBox="0 0 24 24" fill="none" stroke="#1f6fe5" strokeWidth="2">
                          <rect x="4" y="4" width="16" height="16" rx="2"/>
                          <path d="M8 9h8M8 13h5" strokeLinecap="round"/>
                        </svg>
                        Guru
                      </label>

                      {/* Admin */}
                      <input 
                        type="radio" 
                        name="peran" 
                        id="peran-admin" 
                        value="admin"
                        checked={peran === 'admin'}
                        onChange={() => {
                          setPeran('admin');
                          setGender('laki-laki');
                        }}
                      />
                      <label htmlFor="peran-admin" className="pill">
                        <svg viewBox="0 0 24 24" fill="none" stroke="#1f6fe5" strokeWidth="2">
                          <circle cx="12" cy="12" r="3"/>
                          <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.04 1.56V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 8.96 19.3a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.04H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.7 8.96a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34H9.1A1.7 1.7 0 0 0 10.14 3H10.09a2 2 0 1 1 4 0v.09c.02.68.42 1.28 1.05 1.56"/>
                        </svg>
                        Admin
                      </label>
                    </div>
                  </div>

                  {/* Field: Jenis Kelamin */}
                  <div className="field">
                    <label className="group-label">Jenis Kelamin</label>
                    <div className="pill-group" role="radiogroup" aria-label="Jenis Kelamin">
                      {/* Laki-laki */}
                      <input 
                        type="radio" 
                        name="gender" 
                        id="gender-l" 
                        value="laki-laki" 
                        checked={gender === 'laki-laki'}
                        onChange={() => setGender('laki-laki')}
                      />
                      <label htmlFor="gender-l" className="pill">Laki-laki</label>

                      {/* Perempuan */}
                      {peran !== 'admin' && (
                        <>
                          <input 
                            type="radio" 
                            name="gender" 
                            id="gender-p" 
                            value="perempuan"
                            checked={gender === 'perempuan'}
                            onChange={() => setGender('perempuan')}
                          />
                          <label htmlFor="gender-p" className="pill">Perempuan</label>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Field: Kelas - Only visible if 'Siswa' is selected */}
                  {peran === 'siswa' && (
                    <div className="field">
                      <label className="group-label" htmlFor="kelas">Kelas</label>
                      <select 
                        id="kelas" 
                        name="kelas" 
                        value={kelas}
                        onChange={(e) => setKelas(e.target.value)}
                      >
                        <option value="7">Kelas 7</option>
                        <option value="8">Kelas 8</option>
                        <option value="9">Kelas 9</option>
                      </select>
                    </div>
                  )}

                  {/* Field: Mode Offline */}
                  <div className="field mt-4">
                    <div className="flex items-center justify-between bg-slate-50 border border-slate-100 rounded-xl p-3.5 shadow-sm">
                      <div className="flex items-center gap-2.5">
                        <Globe className={`w-4.5 h-4.5 transition-colors duration-300 ${offline ? 'text-amber-500 animate-pulse' : 'text-blue-500'}`} />
                        <div className="text-left">
                          <p className="text-[11px] font-extrabold text-slate-800">Mode Belajar Luring (Offline)</p>
                          <p className="text-[9px] text-slate-500 font-bold leading-none">Simpan data di browser tanpa internet</p>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const newValue = !offline;
                          setOfflineState(newValue);
                          setOfflineMode(newValue);
                        }}
                        className={`relative inline-flex h-5 w-10 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          offline ? 'bg-amber-500' : 'bg-slate-200'
                        }`}
                      >
                        <span
                          className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                            offline ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button type="submit" className="btn-submit mt-4" disabled={isLoading}>
                    {isLoading ? 'Memeriksa…' : 'Masuk'}
                  </button>
                </form>

                {/* Under Development Badge */}
                <div className="signup-badge">
                  <span className="flex items-center justify-center gap-1.5 text-[#0d3b78] select-none">
                    <Construction className="w-4 h-4 text-[#ffb020] shrink-0" />
                    Website ini sedang dikembangkan
                  </span>
                </div>

                {/* Beautiful Action switch button */}
                <button
                  type="button"
                  onClick={() => setActiveView('proverb')}
                  className="w-full mt-3 py-2.5 px-3 rounded-lg border border-amber-200 bg-amber-50/50 hover:bg-amber-50 text-amber-800 text-xs font-bold flex items-center justify-center gap-1.5 transition duration-150 cursor-pointer shadow-sm hover:shadow"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                  Buka Kata Mutiara & Mahfuzhat Hari Ini
                  <ArrowRight className="w-3.5 h-3.5 text-amber-500 ml-0.5" />
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="proverb-view"
                initial={{ opacity: 0, x: 16, scale: 0.98 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -16, scale: 0.98 }}
                transition={{ duration: 0.25, ease: "easeInOut" }}
                className="flex flex-col"
              >
                {/* Badge/Emblem with Quote Icon */}
                <div className="mark bg-gradient-to-tr from-amber-400 to-amber-600 border border-amber-200/50">
                  <Quote className="w-5 h-5 text-white" />
                </div>

                {/* Title */}
                <div className="text-center mb-1">
                  <span className="inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-200">
                    KATA MUTIARA • PEPATAH ARAB
                  </span>
                </div>
                <p className="sub text-xs text-[#4a5f78] text-center mb-5">Motivasi & Mahfuzhat Harian Pemula</p>

                {/* Extremely Clear Arabic Proverb Box (Noto Naskh Arabic font loaded) */}
                <div className="text-center bg-gradient-to-b from-amber-50/70 to-amber-50/30 rounded-xl p-6 border border-amber-100/80 mb-4 relative shadow-sm min-h-[170px] flex flex-col justify-center">
                  {/* Decorative quote mark */}
                  <span className="absolute -top-3 left-4 text-4xl text-amber-300/40 font-serif leading-none select-none">“</span>
                  
                  {/* Arabic text rendered super crisp, prominent & clean */}
                  <h2 
                    className="arabic text-[#0d3b78] leading-normal mb-3 tracking-wide drop-shadow-sm select-all text-center"
                    style={{
                      fontFamily: arabicFontFamily,
                      fontSize: `${28 * arabicScale}px`,
                      fontWeight: isArabicBold ? 'bold' : 'normal',
                    }}
                  >
                    {ARABIC_QUOTES[currentQuoteIndex].arabic}
                  </h2>
                  
                  {/* Pronunciation Transliteration */}
                  <p className="font-semibold text-amber-800 text-sm italic tracking-wide font-serif">
                    &ldquo;{ARABIC_QUOTES[currentQuoteIndex].pronunciation}&rdquo;
                  </p>

                  {/* Indonesian translation with clear high-contrast display */}
                  <p className="mt-3.5 text-[#0f2743] font-bold text-base leading-relaxed">
                    {ARABIC_QUOTES[currentQuoteIndex].translation}
                  </p>

                  <span className="absolute -bottom-8 right-4 text-4xl text-amber-300/40 font-serif leading-none select-none">”</span>
                </div>

                {/* Dots / Selectors Indicator */}
                <div className="flex justify-center items-center gap-1.5 mb-5">
                  <button
                    onClick={() => setCurrentQuoteIndex((prev) => (prev - 1 + ARABIC_QUOTES.length) % ARABIC_QUOTES.length)}
                    className="p-1 rounded-full hover:bg-amber-100 text-amber-800 transition cursor-pointer"
                    title="Sebelumnya"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>

                  <div className="flex gap-1.5 mx-2">
                    {ARABIC_QUOTES.map((_, qIdx) => (
                      <button
                        key={qIdx}
                        onClick={() => setCurrentQuoteIndex(qIdx)}
                        className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                          currentQuoteIndex === qIdx
                            ? 'bg-amber-500 w-6'
                            : 'bg-amber-200 hover:bg-amber-300'
                        }`}
                        title={`Kata Mutiara ${qIdx + 1}`}
                      />
                    ))}
                  </div>

                  <button
                    onClick={() => setCurrentQuoteIndex((prev) => (prev + 1) % ARABIC_QUOTES.length)}
                    className="p-1 rounded-full hover:bg-amber-100 text-amber-800 transition cursor-pointer"
                    title="Berikutnya"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Descriptive moral advice */}
                <p className="text-xs text-[#4a5f78] leading-relaxed text-center mb-6 px-1.5 font-semibold bg-slate-50/50 py-3 rounded-lg border border-slate-100">
                  {ARABIC_QUOTES[currentQuoteIndex].advice}
                </p>

                {/* Navigation Button back to Login */}
                <button
                  type="button"
                  onClick={() => setActiveView('login')}
                  className="w-full py-2.5 rounded-lg bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all duration-150 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-4 h-4" />
                  Kembali ke Halaman Masuk
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  </motion.div>
        ) : (
          <motion.div
            key="dashboard-stage"
            initial={{ opacity: 0, scale: 1.02, filter: 'blur(12px)' }}
            animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 0.98, filter: 'blur(8px)' }}
            transition={{ duration: 0.55, ease: [0.34, 1.56, 0.64, 1] }}
            className="w-full h-full relative"
          >
            <DashboardView 
              session={session} 
              onLogout={() => {
                setSession(null);
                setStatusMessage(null);
                setStatusType(null);
              }} 
              arabicScale={arabicScale}
              setArabicScale={setArabicScale}
              arabicFontFamily={arabicFontFamily}
              setArabicFontFamily={setArabicFontFamily}
              isArabicBold={isArabicBold}
              setIsArabicBold={setIsArabicBold}
            />
            
            {/* PINNED SIDEBAR VERTICAL SLIDER ON THE RIGHT SIDE */}
            <div 
              className="fixed right-0 top-[18%] h-[52%] w-10 z-50 bg-white/95 backdrop-blur border-l border-y border-slate-200/90 rounded-l-2xl shadow-xl flex flex-col items-center justify-between py-5 select-none transition-all hover:w-11"
              style={{ touchAction: 'none' }}
            >
              {/* Slanted vertical text label on hover or default */}
              <div className="absolute -left-12 top-1/2 -translate-y-1/2 -rotate-90 origin-center flex items-center gap-1 pointer-events-none">
                <span className="text-[8px] font-extrabold tracking-widest text-slate-400 uppercase">GESER UKURAN</span>
                <span className="text-amber-500 font-extrabold text-[9px]">ع</span>
              </div>

              {/* Small top indicator button */}
              <button 
                onClick={() => setArabicScale(prev => Math.min(2.5, Number((prev + 0.1).toFixed(2))))}
                className="text-slate-400 hover:text-[#0d3b78] hover:bg-slate-100 transition p-1 rounded-full cursor-pointer"
                title="Perbesar Ukuran Arab"
              >
                <ChevronUp className="w-4 h-4" />
              </button>

              {/* Vertical sliding track */}
              <div className="relative w-1.5 h-3/5 bg-slate-100 border border-slate-200/60 rounded-full flex items-center justify-center">
                {/* Active progress fill */}
                <div 
                  className="absolute bottom-0 w-full bg-amber-400 rounded-full"
                  style={{ height: `${((arabicScale - 0.8) / 1.7) * 100}%` }}
                />

                {/* Draggable Circle Handle with Pointer Capture */}
                <motion.div
                  onPointerDown={(e) => {
                    setIsDragging(true);
                    dragStartY.current = e.clientY;
                    dragStartScale.current = arabicScale;
                    e.currentTarget.setPointerCapture(e.pointerId);
                  }}
                  onPointerMove={(e) => {
                    if (!isDragging) return;
                    const deltaY = dragStartY.current - e.clientY; // Drag UP increases scale
                    const newScale = Math.min(2.5, Math.max(0.8, dragStartScale.current + (deltaY / 100)));
                    setArabicScale(Number(newScale.toFixed(2)));
                  }}
                  onPointerUp={(e) => {
                    setIsDragging(false);
                    e.currentTarget.releasePointerCapture(e.pointerId);
                  }}
                  className={`absolute w-7 h-7 rounded-full bg-[#0d3b78] text-white shadow-md flex items-center justify-center cursor-ns-resize border-2 border-white select-none transition-colors ${
                    isDragging ? 'bg-amber-400 ring-4 ring-amber-500/30 scale-110' : 'hover:bg-[#1f6fe5]'
                  }`}
                  style={{
                    bottom: `calc(${((arabicScale - 0.8) / 1.7) * 100}% - 14px)`,
                    touchAction: 'none'
                  }}
                  title="Tarik Naik-Turun untuk Mengubah Ukuran Arab"
                >
                  <span className="text-[7.5px] font-black">{Math.round(arabicScale * 100)}%</span>
                </motion.div>
              </div>

              {/* Small bottom indicator button */}
              <button 
                onClick={() => setArabicScale(prev => Math.max(0.8, Number((prev - 0.1).toFixed(2))))}
                className="text-slate-400 hover:text-[#0d3b78] hover:bg-slate-100 transition p-1 rounded-full cursor-pointer"
                title="Perkecil Ukuran Arab"
              >
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
